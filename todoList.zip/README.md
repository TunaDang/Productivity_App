# Ocaml_Todo_List
Cornell CS 3110 final project. Productivity Application

## To Do List
Our app will be able to display the to do list.

## Calendar
Our app will be able to display the calendar.
